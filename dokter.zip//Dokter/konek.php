<?php
	$konek = new mysqli('localhost','root','','dokter');
?>