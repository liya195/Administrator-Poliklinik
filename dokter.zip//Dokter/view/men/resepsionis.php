
			<li>
				<a href="index.php?hal=pasien&act=view" clas="amenu">Pasien</a>
			</li>
			<li>
				<a href="index.php?hal=pendaftaran&act=view" clas="amenu">Pendaftaran</a>
			</li>